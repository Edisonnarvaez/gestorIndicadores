from rest_framework import status, viewsets
from rest_framework.decorators import action, api_view
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import get_user_model, authenticate
from django.core.mail import send_mail
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.tokens import PasswordResetTokenGenerator
import pyotp
from users.serializers.user_serializer import UserSerializer, LoginSerializer


User = get_user_model()

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    def get_tokens_for_user(self, user):
        """Genera los tokens JWT para el usuario."""
        refresh = RefreshToken.for_user(user)
        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token)
        }

    @action(detail=False, methods=['post'])
    def login(self, request):
        """Autenticación con username y password. Si tiene 2FA activado, solicita el código OTP."""
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            username = serializer.validated_data['username']
            password = serializer.validated_data['password']
            user = authenticate(username=username, password=password)

            if user is not None:
                if user.otp_secret:
                    return Response({'message': 'Ingrese su código 2FA', 'user_id': user.id}, status=status.HTTP_200_OK)
                
                tokens = self.get_tokens_for_user(user)
                return Response(tokens, status=status.HTTP_200_OK)
            return Response({'error': 'Invalid username or password'}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=['post'])
    def verify_2fa(self, request):
        """Verifica el código 2FA y devuelve un token JWT."""
        user_id = request.data.get('user_id')
        otp_code = request.data.get('otp_code')
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response({'error': 'Usuario no encontrado'}, status=status.HTTP_404_NOT_FOUND)
        
        if not user.otp_secret or not user.verify_otp(otp_code):
            return Response({'error': 'Código incorrecto o 2FA no activado'}, status=status.HTTP_400_BAD_REQUEST)
        
        tokens = self.get_tokens_for_user(user)
        return Response(tokens, status=status.HTTP_200_OK)

    @action(detail=False, methods=['post'])
    def enable_2fa(self, request):
        """Habilita el 2FA generando una clave secreta para el usuario."""
        user = request.user
        user.generate_otp_secret()
        return Response({'message': '2FA activado', 'secret': user.otp_secret}, status=status.HTTP_200_OK)

    @action(detail=False, methods=['post'])
    def disable_2fa(self, request):
        """Desactiva el 2FA eliminando la clave secreta."""
        user = request.user
        user.otp_secret = None
        user.save()
        return Response({'message': '2FA desactivado'}, status=status.HTTP_200_OK)

class PasswordResetRequestView(APIView):
    def post(self, request):
        """Genera un token para restablecer contraseña y envía un email."""
        email = request.data.get('email')
        try:
            user = User.objects.get(email=email)
            token = PasswordResetTokenGenerator().make_token(user)
            reset_url = f"http://localhost:5173/password-reset-confirm/{user.pk}/{token}/"
            send_mail(
                'Password Reset Request',
                f'Click the link to reset your password: {reset_url}',
                'noreply@example.com',
                [email],
                fail_silently=False,
            )
            return Response({'message': 'Password reset link sent'}, status=status.HTTP_200_OK)
        except User.DoesNotExist:
            return Response({'error': 'User not found'}, status=status.HTTP_400_BAD_REQUEST)

class PasswordResetConfirmView(APIView):
    def post(self, request, user_id, token):
        """Confirma el restablecimiento de contraseña y actualiza la nueva clave."""
        try:
            user = User.objects.get(pk=user_id)
            if PasswordResetTokenGenerator().check_token(user, token):
                new_password = request.data.get('new_password')
                if new_password:
                    user.set_password(new_password)
                    user.save()
                    return Response({'message': 'Password updated successfully'}, status=status.HTTP_200_OK)
                return Response({'error': 'New password required'}, status=status.HTTP_400_BAD_REQUEST)
            return Response({'error': 'Invalid token'}, status=status.HTTP_400_BAD_REQUEST)
        except User.DoesNotExist:
            return Response({'error': 'User not found'}, status=status.HTTP_400_BAD_REQUEST)
        
