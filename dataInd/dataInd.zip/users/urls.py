from django.urls import path, include
from rest_framework.routers import DefaultRouter
from users.views.role_view import RoleViewSet
from users.views.user_view import UserViewSet


router = DefaultRouter()
router.register(r'users', UserViewSet)
router.register(r'roles', RoleViewSet)

urlpatterns = [
    path('', include(router.urls)),

    #path("login/", UserViewSet.as_view({"post": "login"}), name="login"),
    #path("verify-2fa/", UserViewSet.as_view({"post": "verify_2fa"}), name="verify_2fa"),
    #path("enable-2fa/", UserViewSet.as_view({"post": "enable_2fa"}), name="enable_2fa"),
    #path("disable-2fa/", UserViewSet.as_view({"post": "disable_2fa"}), name="disable_2fa"),
    
]

